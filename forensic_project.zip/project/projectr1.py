#importing libraries
import cv2
from deepface import DeepFace

faceCascade=cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
cap =cv2.VideoCapture(1)
count=0

#check the functioning of the webcam
if not cap.isOpened():
    cap=cv2.VideoCapture(0)
if not cap.isOpened():
    raise IOError("Webcam not detected")

while True:
    #reading one image from video
    ret,frame=cap.read()

    result=DeepFace.analyze(frame,actions=['emotion'])

    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    faces=faceCascade.detectMultiScale(gray,1.1,4)
    

    #Draw a rectangle around the detected faces
    for(x,y,w,h) in faces:
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
    font=cv2.FONT_HERSHEY_DUPLEX
    if(result['dominant_emotion']=='happy'):
        result['dominant_emotion']='confident'
    if(result['dominant_emotion']=='fear'):
        count=count+1
        if(count>=5):
            result['dominant_emotion']='liar_suspected'
        


    #inserting the text in the image extracted from video
    cv2.putText(frame,result['dominant_emotion'],(50,50),font,3,(0,0,255),2,cv2.LINE_4)
    cv2.imshow('Original video',frame)
    if cv2.waitKey(2) & 0xFF==ord('q'):
        break
cap.release()
cv2.destroyAllWindows()
